package com.nocturna.cam

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageFormat
import android.graphics.Paint
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.roundToInt

enum class Mode(val title: String) {
    FOTO("Foto"), NOCHE("Noche"), LARGA("Larga exp."), VIDEO("Video")
}

class MainActivity : Activity() {

    private lateinit var mgr: CameraManager
    private lateinit var texture: TextureView
    private lateinit var status: TextView
    private lateinit var shutterBtn: Button
    private lateinit var lensBtn: Button
    private val modeBtns = mutableMapOf<Mode, TextView>()

    private var lenses: List<Lens> = emptyList()
    private var lensIdx = 0
    private var mode = Mode.FOTO

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var chars: CameraCharacteristics? = null
    private var pSurf: Surface? = null

    private var jpegSize = Size(3264, 2448)
    private var previewSize = Size(1440, 1080)
    private var videoSize = Size(1920, 1080)

    private var bgThread: HandlerThread? = null
    private var bg: Handler = Handler(Looper.getMainLooper())
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var busy = false
    @Volatile private var cancel = false
    private val frames = LinkedBlockingQueue<ByteArray>()

    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recUri: Uri? = null
    private var recording = false

    // ---- Ajustes ----
    private var evIdx = 0
    private var focusP = 0
    private var wbIdx = 0
    private var manualExp = false
    private var manualIso = 400
    private var manualShutterIdx = -1
    private var nightFramesIdx = 1
    private var nightGreen = true
    private var longSecIdx = 3
    private var longIso = 200
    private var trails = false
    private var lowLightVideo = false

    private val nightFrameOptions = listOf(4, 8, 12, 16)
    private val longSecOptions = listOf(1, 2, 5, 10, 15, 20, 30, 45, 60)
    private val wbOptions = listOf(
        "Automático" to CaptureRequest.CONTROL_AWB_MODE_AUTO,
        "Luz de día" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
        "Nublado" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
        "Lámpara cálida" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
        "Luz fluorescente" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
    )

    // =====================================================================
    // Ciclo de vida
    // =====================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mgr = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        if (!hasCam()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        startBg()
        startCamera()
    }

    override fun onPause() {
        cancel = true
        if (recording) stopRecording(false)
        closeCamera()
        bgThread?.quitSafely()
        bgThread = null
        super.onPause()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasCam()) startCamera() else toast("Sin permiso de cámara no puedo funcionar. Activalo en Ajustes del teléfono.")
    }

    private fun hasCam() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun startBg() {
        if (bgThread == null) {
            val t = HandlerThread("camara")
            t.start()
            bgThread = t
            bg = Handler(t.looper)
        }
    }

    private fun startCamera() {
        if (!hasCam() || !texture.isAvailable) return
        startBg()
        if (lenses.isEmpty()) {
            lenses = try { Lenses.discover(this) } catch (e: Exception) { emptyList() }
            lensIdx = 0
            updateLensButton()
        }
        if (lenses.isEmpty()) {
            toast("No encontré cámaras utilizables.")
            return
        }
        openCamera()
    }

    // =====================================================================
    // Cámara
    // =====================================================================

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        closeCamera()
        val lens = lenses[lensIdx]
        chars = try {
            mgr.getCameraCharacteristics(lens.physicalId ?: lens.logicalId)
        } catch (e: Exception) {
            mgr.getCameraCharacteristics(lens.logicalId)
        }
        try {
            mgr.openCamera(lens.logicalId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    ui.post { createSession() }
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    if (device === camera) device = null
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    if (device === camera) device = null
                    toast("Error de cámara ($error). Cerrá otras apps que usen la cámara e intentá de nuevo.")
                }
            }, bg)
        } catch (e: Exception) {
            toast("No pude abrir la cámara: ${e.message}")
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (e: Exception) { }
        try { device?.close() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        session = null
        device = null
        reader = null
    }

    private fun supports(key: CameraCharacteristics.Key<IntArray>, v: Int): Boolean =
        chars?.get(key)?.contains(v) == true

    private fun createSession() {
        val dev = device ?: return
        val c = chars ?: return
        val lens = lenses[lensIdx]
        try {
            try { session?.close() } catch (e: Exception) { }
            session = null
            try { reader?.close() } catch (e: Exception) { }
            reader = null

            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return

            val limit = if (mode == Mode.FOTO) 13_000_000L else 8_000_000L
            val jp = map.getOutputSizes(ImageFormat.JPEG)?.toList().orEmpty()
            if (jp.isNotEmpty()) {
                jpegSize = jp.filter { it.width.toLong() * it.height <= limit }
                    .maxByOrNull { it.width.toLong() * it.height }
                    ?: jp.minByOrNull { it.width.toLong() * it.height }!!
            }
            val vs = map.getOutputSizes(MediaRecorder::class.java)?.toList().orEmpty()
            videoSize = vs.firstOrNull { it.width == 1920 && it.height == 1080 }
                ?: vs.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
                ?: Size(1280, 720)

            val target = if (mode == Mode.VIDEO) videoSize else jpegSize
            val ar = target.width.toFloat() / target.height
            val ps = map.getOutputSizes(SurfaceTexture::class.java)?.toList().orEmpty()
            previewSize = ps.filter {
                abs(it.width.toFloat() / it.height - ar) < 0.02f && it.width <= 1920 && it.height <= 1440
            }.maxByOrNull { it.width * it.height }
                ?: ps.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
                ?: Size(1280, 720)
            layoutTexture()

            val st = texture.surfaceTexture ?: return
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            if (pSurf == null) pSurf = Surface(st)
            val preview = pSurf!!

            val outs = mutableListOf(preview)
            if (mode == Mode.VIDEO) {
                if (recording) recorder?.surface?.let { outs.add(it) }
            } else {
                val rd = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 3)
                rd.setOnImageAvailableListener({ r ->
                    val img = r.acquireNextImage()
                    if (img != null) {
                        try {
                            val buf = img.planes[0].buffer
                            val bytes = ByteArray(buf.remaining())
                            buf.get(bytes)
                            frames.offer(bytes)
                        } finally {
                            img.close()
                        }
                    }
                }, bg)
                reader = rd
                outs.add(rd.surface)
            }

            val cfgs = outs.map { s ->
                val oc = OutputConfiguration(s)
                val pid = lens.physicalId
                if (pid != null) oc.setPhysicalCameraId(pid)
                oc
            }
            val sc = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                cfgs,
                Executor { r -> bg.post(r) },
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        startRepeating()
                        if (recording) {
                            try { recorder?.start() } catch (e: Exception) { toast("No pude iniciar la grabación: ${e.message}") }
                        }
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        ui.post { fallbackLens() }
                    }
                }
            )
            dev.createCaptureSession(sc)
        } catch (e: Exception) {
            toast("No pude preparar la cámara: ${e.message}")
        }
    }

    private fun fallbackLens() {
        val l = lenses[lensIdx]
        if (l.physicalId != null) {
            toast("Tu teléfono no deja abrir «${l.label}» por separado. Uso el lente principal en su lugar.")
            lenses = lenses.toMutableList().also { it[lensIdx] = l.copy(physicalId = null) }
            openCamera()
        } else {
            toast("No pude iniciar la cámara.")
        }
    }

    private fun layoutTexture() {
        val sw = resources.displayMetrics.widthPixels
        val h = (sw.toFloat() * previewSize.width / previewSize.height).toInt()
        ui.post {
            val lp = FrameLayout.LayoutParams(sw, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            lp.topMargin = dp(56)
            texture.layoutParams = lp
        }
    }

    // =====================================================================
    // Solicitudes de captura
    // =====================================================================

    private fun isoList(): List<Int> {
        val r = chars?.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: return listOf(100)
        return listOf(50, 100, 200, 400, 800, 1600, 3200, 6400, 12800)
            .filter { it >= r.lower && it <= r.upper }
            .ifEmpty { listOf(r.lower) }
    }

    private fun snapIso(v: Int): Int = isoList().minByOrNull { abs(it - v) } ?: v

    private fun shutterList(): List<Long> {
        val r = chars?.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: return listOf(16_666_666L)
        val denoms = listOf(8000, 4000, 2000, 1000, 500, 250, 125, 60, 30, 15, 8, 4, 2)
        val all = denoms.map { 1_000_000_000L / it } + listOf(1_000_000_000L)
        return all.filter { it >= r.lower && it <= r.upper }.ifEmpty { listOf(r.lower) }
    }

    private fun shutterNs(): Long {
        val l = shutterList()
        if (manualShutterIdx !in l.indices) {
            val i = l.indexOfFirst { it >= 16_000_000L }
            manualShutterIdx = if (i < 0) l.size - 1 else i
        }
        return l[manualShutterIdx]
    }

    private fun shutterLabel(ns: Long): String =
        if (ns >= 1_000_000_000L) "${ns / 1_000_000_000L} s" else "1/${(1e9 / ns).roundToInt()} s"

    private fun hwMaxNs(): Long {
        val r = chars?.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: return 100_000_000L
        val md = chars?.get(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION)
        return if (md != null && md > 0L) min(r.upper, md) else r.upper
    }

    private fun lowFps(minUpper: Int): Range<Int>? {
        val a = chars?.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList().orEmpty()
        val ok = a.filter { it.upper >= minUpper }
        return ok.minWithOrNull(compareBy<Range<Int>>({ it.upper }, { it.lower }))
    }

    private fun evRange(): Range<Int> =
        chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)

    private fun applyCommon(b: CaptureRequest.Builder) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)

        val wb = wbOptions[wbIdx].second
        b.set(
            CaptureRequest.CONTROL_AWB_MODE,
            if (supports(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES, wb)) wb
            else CaptureRequest.CONTROL_AWB_MODE_AUTO
        )

        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val afMode = if (mode == Mode.VIDEO) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
        else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
        val manualFocus = minFocus > 0f && (focusP > 0 || mode == Mode.LARGA)
        if (manualFocus) {
            val d = if (focusP > 0) (focusP - 1) / 99f * minFocus else 0f
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, d)
        } else if (supports(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES, afMode)) {
            b.set(CaptureRequest.CONTROL_AF_MODE, afMode)
        }
    }

    private fun autoAe(b: CaptureRequest.Builder) {
        val r = evRange()
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx.coerceIn(r.lower, r.upper))
    }

    private fun nightAe(b: CaptureRequest.Builder, minUpper: Int) {
        val r = evRange()
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, r.upper)
        lowFps(minUpper)?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
    }

    private fun manualAe(b: CaptureRequest.Builder, iso: Int, ns: Long) {
        val c = chars ?: return
        val sr = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val er = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val i = if (sr != null) iso.coerceIn(sr.lower, sr.upper) else iso
        val t = if (er != null) ns.coerceIn(er.lower, er.upper) else ns
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        b.set(CaptureRequest.SENSOR_SENSITIVITY, i)
        b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, t)
        b.set(CaptureRequest.SENSOR_FRAME_DURATION, if (t > 33_333_333L) t else 33_333_333L)
    }

    private fun startRepeating() {
        val s = session ?: return
        val d = device ?: return
        val ps = pSurf ?: return
        try {
            val tpl = if (mode == Mode.VIDEO && recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW
            val b = d.createCaptureRequest(tpl)
            b.addTarget(ps)
            if (mode == Mode.VIDEO && recording) recorder?.surface?.let { b.addTarget(it) }
            applyCommon(b)
            when {
                mode == Mode.NOCHE || mode == Mode.LARGA -> nightAe(b, 5)
                mode == Mode.VIDEO && lowLightVideo -> nightAe(b, 15)
                mode == Mode.FOTO && manualExp -> manualAe(b, snapIso(manualIso), shutterNs())
                else -> autoAe(b)
            }
            s.setRepeatingRequest(b.build(), null, bg)
        } catch (e: Exception) {
        }
    }

    private fun updatePreview() {
        if (busy) return
        bg.post { startRepeating() }
    }

    private fun stillRequest(perFrameNs: Long?, rotateInCamera: Boolean): CaptureRequest {
        val d = device!!
        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(reader!!.surface)
        applyCommon(b)
        when (mode) {
            Mode.LARGA -> manualAe(b, snapIso(longIso), perFrameNs ?: 100_000_000L)
            Mode.NOCHE -> nightAe(b, 5)
            else -> if (manualExp) manualAe(b, snapIso(manualIso), shutterNs()) else autoAe(b)
        }
        val rot = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        b.set(CaptureRequest.JPEG_ORIENTATION, if (rotateInCamera) rot else 0)
        b.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
        if (supports(
                CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES,
                CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY
            )
        ) {
            b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        }
        return b.build()
    }

    // =====================================================================
    // Disparo
    // =====================================================================

    private fun onShutter() {
        if (device == null || session == null) {
            toast("La cámara todavía no está lista.")
            return
        }
        if (busy) {
            cancel = true
            toast("Cancelando…")
            return
        }
        when (mode) {
            Mode.FOTO -> runBurst(1, null, null)
            Mode.NOCHE -> runBurst(nightFrameOptions[nightFramesIdx], null, Combine.AVG)
            Mode.LARGA -> {
                val (n, per) = longPlan()
                val comb = if (n == 1) null else if (trails) Combine.MAX else Combine.SUM
                runBurst(n, per, comb)
            }
            Mode.VIDEO -> toggleRecording()
        }
    }

    private fun longPlan(): Pair<Int, Long> {
        val totalNs = longSecOptions[longSecIdx] * 1_000_000_000L
        val hw = hwMaxNs()
        val n = ceil(totalNs.toDouble() / hw.toDouble()).toInt().coerceIn(1, 150)
        val per = if (n.toLong() * hw < totalNs) hw else totalNs / n
        return Pair(n, per)
    }

    private fun longSummary(): String {
        val (n, per) = longPlan()
        val total = longSecOptions[longSecIdx]
        val perS = per / 1e9
        return if (n == 1) {
            "Se hará 1 sola exposición de %d s.".format(total)
        } else if (n * per < total * 1_000_000_000L - 1_000_000L) {
            "Tu cámara admite %.1f s por toma. Con %d tomas el máximo posible es %.0f s.".format(perS, n, n * perS)
        } else {
            "Tu cámara admite hasta %.1f s por toma, así que se hacen %d tomas y se suman (equivale a %d s). Es normal que tarde un poco más.".format(
                hwMaxNs() / 1e9, n, total
            )
        }
    }

    private fun runBurst(total: Int, perFrameNs: Long?, combine: Combine?) {
        if (busy) return
        val s = session ?: return
        val rot = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        busy = true
        cancel = false
        updateShutter()
        Thread {
            var single: ByteArray? = null
            var stk: Stacker? = null
            var done = 0
            var error: String? = null
            try {
                frames.clear()
                try { s.stopRepeating() } catch (e: Exception) { }
                for (i in 1..total) {
                    if (cancel) break
                    val waitS = (perFrameNs ?: 1_000_000_000L) / 1_000_000_000L + 12L
                    s.capture(stillRequest(perFrameNs, combine == null), null, bg)
                    val bytes = frames.poll(waitS, TimeUnit.SECONDS)
                        ?: throw RuntimeException("La cámara no respondió a tiempo")
                    if (combine == null) {
                        single = bytes
                    } else {
                        val st = stk ?: Stacker(combine, rot)
                        stk = st
                        if (!st.add(bytes)) throw RuntimeException("No pude procesar una de las tomas")
                    }
                    done = i
                    val left = total - i
                    val msg = if (perFrameNs != null && total > 1) {
                        "Toma $i de $total · faltan ≈ ${left * perFrameNs / 1_000_000_000L} s"
                    } else {
                        "Toma $i de $total"
                    }
                    ui.post { status.text = msg }
                }
            } catch (t: Throwable) {
                error = if (t is OutOfMemoryError) {
                    "Memoria insuficiente. Probá con menos tiempo o menos fotos."
                } else {
                    t.message ?: "Error desconocido"
                }
            }

            var result: String? = null
            if (done > 0) {
                try {
                    val sg = single
                    val st = stk
                    val uri: Uri? = if (combine == null) {
                        if (sg != null) saveImage { o -> o.write(sg) } else null
                    } else if (st != null) {
                        val bmp = st.result()
                        if (bmp != null) {
                            val u = saveImage { o -> bmp.compress(Bitmap.CompressFormat.JPEG, 95, o) }
                            bmp.recycle()
                            u
                        } else null
                    } else null
                    if (uri != null) {
                        result = if (cancel) "Cancelado. Guardé lo que alcanzó a capturar (Pictures/CamaraNocturna)."
                        else "Foto guardada en Pictures/CamaraNocturna"
                    }
                } catch (t: Throwable) {
                    error = if (t is OutOfMemoryError) "Memoria insuficiente al unir las tomas." else (t.message ?: "No pude guardar la foto")
                }
            }
            stk = null
            single = null

            busy = false
            startRepeating()
            val finalMsg = error ?: result ?: "No se guardó ninguna foto."
            ui.post {
                updateShutter()
                updateStatus()
                toast(finalMsg)
            }
        }.start()
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun saveImage(write: (OutputStream) -> Unit): Uri? {
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, "NOC_" + stamp() + ".jpg")
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CamaraNocturna")
        v.put(MediaStore.Images.Media.IS_PENDING, 1)
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        contentResolver.openOutputStream(uri)?.use { write(it) }
        val done = ContentValues()
        done.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, done, null, null)
        return uri
    }

    // =====================================================================
    // Video
    // =====================================================================

    private fun toggleRecording() {
        if (recording) stopRecording(true) else startRecording()
    }

    private fun startRecording() {
        try {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, "VID_" + stamp() + ".mp4")
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CamaraNocturna")
            v.put(MediaStore.Video.Media.IS_PENDING, 1)
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw RuntimeException("No pude crear el archivo")
            val pfd = contentResolver.openFileDescriptor(uri, "rw")
                ?: throw RuntimeException("No pude abrir el archivo")
            val fps = if (lowLightVideo) (lowFps(15)?.upper ?: 30) else 30
            val withAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val r = MediaRecorder()
            if (withAudio) r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(pfd.fileDescriptor)
            r.setVideoEncodingBitRate(14_000_000)
            r.setVideoFrameRate(fps)
            r.setVideoSize(videoSize.width, videoSize.height)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (withAudio) r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOrientationHint(chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90)
            r.prepare()
            recorder = r
            recPfd = pfd
            recUri = uri
            recording = true
            updateShutter()
            createSession()
        } catch (e: Exception) {
            recording = false
            toast("No pude iniciar el video: ${e.message}")
        }
    }

    private fun stopRecording(restart: Boolean) {
        val r = recorder
        val pfd = recPfd
        val uri = recUri
        recording = false
        try { session?.stopRepeating() } catch (e: Exception) { }
        try { session?.abortCaptures() } catch (e: Exception) { }
        try { r?.stop() } catch (e: RuntimeException) { }
        try { r?.reset() } catch (e: Exception) { }
        try { r?.release() } catch (e: Exception) { }
        try { pfd?.close() } catch (e: Exception) { }
        if (uri != null) {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.IS_PENDING, 0)
            try { contentResolver.update(uri, v, null, null) } catch (e: Exception) { }
        }
        recorder = null
        recPfd = null
        recUri = null
        if (restart) {
            toast("Video guardado en Movies/CamaraNocturna")
            createSession()
        }
        updateShutter()
    }

    // =====================================================================
    // Interfaz
    // =====================================================================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        ui.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
    }

    private fun buildUi() {
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        texture = TextureView(this)
        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { startCamera() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) { }
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean {
                try { pSurf?.release() } catch (e: Exception) { }
                pSurf = null
                return true
            }
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) { }
        }
        root.addView(texture, FrameLayout.LayoutParams(dp(300), dp(400), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 13f
        status.setPadding(dp(12), dp(6), dp(12), dp(6))
        status.setBackgroundColor(0x88000000.toInt())
        root.addView(status, FrameLayout.LayoutParams(mp, wc, Gravity.TOP))

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(8), dp(8), dp(8), dp(20))
        panel.setBackgroundColor(0xCC000000.toInt())

        val modes = LinearLayout(this)
        modes.orientation = LinearLayout.HORIZONTAL
        for (m in Mode.values()) {
            val t = TextView(this)
            t.text = m.title
            t.gravity = Gravity.CENTER
            t.textSize = 15f
            t.setPadding(0, dp(10), 0, dp(10))
            t.setOnClickListener { setMode(m) }
            modeBtns[m] = t
            modes.addView(t, LinearLayout.LayoutParams(0, wc, 1f))
        }
        panel.addView(modes, LinearLayout.LayoutParams(mp, wc))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        lensBtn = Button(this)
        lensBtn.isAllCaps = false
        lensBtn.setOnClickListener { pickLens() }
        shutterBtn = Button(this)
        shutterBtn.setOnClickListener { onShutter() }
        val setBtn = Button(this)
        setBtn.text = "⚙ Ajustes"
        setBtn.isAllCaps = false
        setBtn.setOnClickListener { showSettings() }
        row.addView(lensBtn, LinearLayout.LayoutParams(0, wc, 1f))
        val slp = LinearLayout.LayoutParams(dp(76), dp(76))
        slp.setMargins(dp(8), 0, dp(8), 0)
        row.addView(shutterBtn, slp)
        row.addView(setBtn, LinearLayout.LayoutParams(0, wc, 1f))
        panel.addView(row, LinearLayout.LayoutParams(mp, wc))

        root.addView(panel, FrameLayout.LayoutParams(mp, wc, Gravity.BOTTOM))
        setContentView(root)

        refreshModeButtons()
        updateShutter()
        updateLensButton()
        updateStatus()
    }

    private fun hint(): String = when (mode) {
        Mode.FOTO -> "Foto normal. Tocá el botón blanco para sacar."
        Mode.NOCHE -> "Visión nocturna: junta varias fotos para ver y fotografiar con muy poca luz. Apoyá el celular en algo firme."
        Mode.LARGA -> "Larga exposición: ideal para estrellas, luces en movimiento y agua. Necesita trípode o un apoyo firme."
        Mode.VIDEO -> "Video. Para poca luz activá «Video con poca luz» en Ajustes."
    }

    private fun updateStatus() {
        val name = if (lenses.isEmpty()) "" else lenses[lensIdx].label + "\n"
        status.text = name + hint()
    }

    private fun updateLensButton() {
        lensBtn.text = if (lenses.isEmpty()) "Lente" else "📷 " + lenses[lensIdx].label
    }

    private fun refreshModeButtons() {
        for ((m, t) in modeBtns) {
            t.setTextColor(if (m == mode) 0xFFFFD54F.toInt() else Color.WHITE)
            t.setTypeface(null, if (m == mode) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun updateShutter() {
        ui.post {
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(if (recording) 0xFFE53935.toInt() else Color.WHITE)
            d.setStroke(dp(4), 0xFF888888.toInt())
            shutterBtn.background = d
            shutterBtn.text = if (busy || recording) "■" else ""
            shutterBtn.setTextColor(if (recording) Color.WHITE else Color.BLACK)
        }
    }

    private fun applyTint() {
        val p = Paint()
        if ((mode == Mode.NOCHE || mode == Mode.LARGA) && nightGreen) {
            val cm = ColorMatrix(
                floatArrayOf(
                    0f, 0f, 0f, 0f, 0f,
                    0.55f, 1.1f, 0.35f, 0f, 15f,
                    0f, 0f, 0f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            p.colorFilter = ColorMatrixColorFilter(cm)
        }
        texture.setLayerPaint(p)
    }

    private fun setMode(m: Mode) {
        if (busy || recording || m == mode) return
        mode = m
        refreshModeButtons()
        applyTint()
        updateStatus()
        if (device != null) createSession()
    }

    private fun pickLens() {
        if (busy || recording) return
        if (lenses.isEmpty()) return
        val names = lenses.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elegí un lente (${lenses.size} disponibles)")
            .setItems(names) { _, i ->
                if (i != lensIdx) {
                    lensIdx = i
                    updateLensButton()
                    updateStatus()
                    openCamera()
                }
            }
            .show()
    }

    // =====================================================================
    // Ajustes (con explicaciones simples)
    // =====================================================================

    private fun showSettings() {
        val c = chars ?: return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(12))
        val sv = ScrollView(this)
        sv.addView(box)

        fun title(t: String) {
            val v = TextView(this)
            v.text = t
            v.textSize = 16f
            v.setTypeface(null, Typeface.BOLD)
            v.setPadding(0, dp(16), 0, 0)
            box.addView(v)
        }

        fun help(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 13f
            v.setTextColor(0xFFAAAAAA.toInt())
            box.addView(v)
            return v
        }

        fun slider(max: Int, start: Int, fmt: (Int) -> String, onChange: (Int) -> Unit) {
            val v = TextView(this)
            v.textSize = 14f
            v.setTextColor(0xFF7FD7FF.toInt())
            v.text = fmt(start)
            val sb = SeekBar(this)
            sb.max = max
            sb.progress = start
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    v.text = fmt(p)
                    onChange(p)
                }
                override fun onStartTrackingTouch(s: SeekBar) { }
                override fun onStopTrackingTouch(s: SeekBar) { }
            })
            box.addView(v)
            box.addView(sb)
        }

        fun switchRow(text: String, on: Boolean, onChange: (Boolean) -> Unit) {
            val sw = Switch(this)
            sw.text = text
            sw.isChecked = on
            sw.setPadding(0, dp(8), 0, dp(4))
            sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
            box.addView(sw)
        }

        val isos = isoList()
        fun isoLabel(i: Int): String {
            val note = when {
                isos[i] <= 200 -> "poco grano, necesita buena luz"
                isos[i] <= 800 -> "equilibrado"
                else -> "ve en la oscuridad, pero con más grano"
            }
            return "ISO ${isos[i]} · $note"
        }

        when (mode) {
            Mode.FOTO -> {
                val er = evRange()
                val step = chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.33f
                title("Brillo")
                help("Movelo a la derecha si la foto sale oscura, a la izquierda si sale muy clara.")
                slider(er.upper - er.lower, evIdx.coerceIn(er.lower, er.upper) - er.lower, { p ->
                    val e = (p + er.lower) * step
                    if (abs(e) < 0.05f) "Normal" else if (e > 0) "Más claro (+%.1f)".format(e) else "Más oscuro (%.1f)".format(e)
                }) { p ->
                    evIdx = p + er.lower
                    updatePreview()
                }

                title("Control manual de la luz")
                help("Apagado: el teléfono decide solo. Encendido: elegís vos cuánta luz entra con los dos controles de abajo.")
                switchRow("Usar control manual", manualExp) { manualExp = it; updatePreview() }

                help("Sensibilidad (ISO): más alto = ve más con poca luz, pero la foto se llena de grano.")
                slider(isos.size - 1, isos.indexOf(snapIso(manualIso)).coerceAtLeast(0), { p -> isoLabel(p) }) { p ->
                    manualIso = isos[p]
                    updatePreview()
                }

                val sh = shutterList()
                val cur = sh.indexOf(shutterNs()).coerceAtLeast(0)
                help("Velocidad: rápido (1/1000) congela el movimiento. Lento (1 s) entra más luz pero lo que se mueve sale movido.")
                slider(sh.size - 1, cur, { p -> "Obturador " + shutterLabel(sh[p]) }) { p ->
                    manualShutterIdx = p
                    updatePreview()
                }
            }

            Mode.NOCHE -> {
                title("Calidad nocturna")
                help("Cuántas fotos une el teléfono para quitar el grano y mostrar más detalle. Más fotos = imagen más limpia, pero tarda más. Mantené el celular quieto.")
                slider(nightFrameOptions.size - 1, nightFramesIdx, { p -> "${nightFrameOptions[p]} fotos" }) { p ->
                    nightFramesIdx = p
                }
                title("Pantalla verde de visión nocturna")
                help("Solo cambia cómo ves la pantalla mientras apuntás. La foto guardada sale a color normal.")
                switchRow("Mostrar en verde", nightGreen) { nightGreen = it; applyTint() }
            }

            Mode.LARGA -> {
                val summary = TextView(this)
                summary.textSize = 13f
                summary.setTextColor(0xFFFFD54F.toInt())
                title("Tiempo de exposición")
                help("Cuánto tiempo la cámara 'junta luz'. Sirve para estrellas, luces de autos que dejan estela o agua suave. Usá trípode o apoyá el celular.")
                slider(longSecOptions.size - 1, longSecIdx, { p -> "${longSecOptions[p]} segundos" }) { p ->
                    longSecIdx = p
                    summary.text = longSummary()
                }
                title("Sensibilidad (ISO)")
                help("Más alto = más luz pero más grano. Para cielo muy oscuro probá ISO alto; para ciudad de noche, ISO bajo.")
                slider(isos.size - 1, isos.indexOf(snapIso(longIso)).coerceAtLeast(0), { p -> isoLabel(p) }) { p ->
                    longIso = isos[p]
                }
                title("Estelas de luz")
                help("Encendido: las estrellas y luces en movimiento dejan una línea. Apagado: se suma toda la luz como una exposición normal.")
                switchRow("Dejar estelas", trails) { trails = it }
                title("Enfoque")
                help("En larga exposición el enfoque queda en 'lejos' (infinito) si lo dejás en Automático, ideal para paisajes y cielo.")
                summary.text = longSummary()
                box.addView(summary)
            }

            Mode.VIDEO -> {
                val er = evRange()
                val step = chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.33f
                title("Video con poca luz")
                help("Graba a menos cuadros por segundo para captar más luz. Se ve menos fluido, pero más claro de noche.")
                switchRow("Activar poca luz", lowLightVideo) { lowLightVideo = it; updatePreview() }
                title("Brillo")
                help("Movelo a la derecha si el video sale oscuro.")
                slider(er.upper - er.lower, evIdx.coerceIn(er.lower, er.upper) - er.lower, { p ->
                    val e = (p + er.lower) * step
                    if (abs(e) < 0.05f) "Normal" else if (e > 0) "Más claro (+%.1f)".format(e) else "Más oscuro (%.1f)".format(e)
                }) { p ->
                    evIdx = p + er.lower
                    updatePreview()
                }
            }
        }

        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (minFocus > 0f) {
            title("Enfoque")
            help("Automático: la cámara enfoca sola. Manual: deslizá desde 'lejos' (estrellas, paisaje) hasta 'muy cerca' (objetos de cerca).")
            slider(100, focusP, { p ->
                when (p) {
                    0 -> "Automático"
                    1 -> "Manual · Lejos (infinito)"
                    100 -> "Manual · Muy cerca"
                    else -> "Manual · $p%"
                }
            }) { p ->
                focusP = p
                updatePreview()
            }
        } else {
            title("Enfoque")
            help("Este lente tiene enfoque fijo, no se puede ajustar.")
        }

        title("Color de la luz (balance de blancos)")
        help("Si la imagen sale amarillenta o azulada, probá otra opción. Automático suele funcionar bien.")
        slider(wbOptions.size - 1, wbIdx, { p -> wbOptions[p].first }) { p ->
            wbIdx = p
            updatePreview()
        }

        AlertDialog.Builder(this)
            .setTitle("Ajustes · " + mode.title)
            .setView(sv)
            .setPositiveButton("Listo", null)
            .show()
    }
}
