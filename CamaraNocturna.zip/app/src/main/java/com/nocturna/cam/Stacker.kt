package com.nocturna.cam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import kotlin.math.pow

enum class Combine { SUM, MAX, AVG }

/**
 * Une varias tomas JPEG en una sola imagen.
 *  SUM = suma la luz (equivale a una exposición larga real)
 *  MAX = se queda con lo más brillante de cada toma (estelas de luz / estrellas)
 *  AVG = promedio (quita el grano en modo noche)
 * Trabaja en luz lineal para que el resultado se parezca a una exposición real.
 */
class Stacker(private val combine: Combine, private val rotation: Int) {
    private var w = 0
    private var h = 0
    private var acc: FloatArray? = null
    private var px: IntArray? = null
    private var count = 0

    private val toLinear = FloatArray(256) { (it / 255f).pow(2.2f) }
    private val toGamma = IntArray(16385) {
        ((it / 16384f).pow(1f / 2.2f) * 255f + 0.5f).toInt().coerceIn(0, 255)
    }

    fun add(jpeg: ByteArray): Boolean {
        val bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return false
        if (acc == null) {
            w = bmp.width
            h = bmp.height
            acc = FloatArray(w * h * 3)
            px = IntArray(w * h)
        }
        if (bmp.width != w || bmp.height != h) {
            bmp.recycle()
            return false
        }
        val a = acc!!
        val p = px!!
        bmp.getPixels(p, 0, w, 0, 0, w, h)
        bmp.recycle()
        var j = 0
        for (v in p) {
            val r = toLinear[(v shr 16) and 255]
            val g = toLinear[(v shr 8) and 255]
            val b = toLinear[v and 255]
            if (combine == Combine.MAX) {
                if (r > a[j]) a[j] = r
                if (g > a[j + 1]) a[j + 1] = g
                if (b > a[j + 2]) a[j + 2] = b
            } else {
                a[j] += r
                a[j + 1] += g
                a[j + 2] += b
            }
            j += 3
        }
        count++
        return true
    }

    private fun idx(x: Float): Int {
        val c = if (x > 1f) 1f else x
        return (c * 16384f).toInt()
    }

    fun result(): Bitmap? {
        val a = acc ?: return null
        val out = px ?: return null
        if (count == 0) return null
        val div = if (combine == Combine.AVG) 1f / count else 1f
        val n = w * h
        for (i in 0 until n) {
            val j = i * 3
            val r = toGamma[idx(a[j] * div)]
            val g = toGamma[idx(a[j + 1] * div)]
            val b = toGamma[idx(a[j + 2] * div)]
            out[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        acc = null
        val bmp = Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        px = null
        if (rotation == 0) return bmp
        val m = Matrix()
        m.postRotate(rotation.toFloat())
        val rotated = Bitmap.createBitmap(bmp, 0, 0, w, h, m, true)
        if (rotated !== bmp) bmp.recycle()
        return rotated
    }
}
