package com.nocturna.cam

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import kotlin.math.hypot

data class Lens(val label: String, val logicalId: String, val physicalId: String?, val front: Boolean)

object Lenses {

    fun discover(ctx: Context): List<Lens> {
        val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ids = mgr.cameraIdList.toList()
        val found = mutableListOf<Lens>()

        for (id in ids) {
            try {
                val c = mgr.getCameraCharacteristics(id)
                val facing = c.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    if (usable(c)) found += Lens("Frontal", id, null, true)
                    continue
                }
                if (facing != CameraCharacteristics.LENS_FACING_BACK) continue

                val phys = c.physicalCameraIds
                if (phys.isEmpty()) {
                    if (usable(c)) found += Lens(name(c), id, null, false)
                } else {
                    // Cámara "lógica" que agrupa varios lentes físicos.
                    for (p in phys) {
                        if (p in ids) continue // se agrega por su cuenta, abre directo
                        try {
                            val pc = mgr.getCameraCharacteristics(p)
                            if (usable(pc)) found += Lens(name(pc), id, p, false)
                        } catch (e: Exception) {
                        }
                    }
                }
            } catch (e: Exception) {
            }
        }

        val order = listOf("Principal", "Ultra gran angular", "Macro", "Teleobjetivo", "Frontal")
        val sorted = found.sortedBy { l ->
            val i = order.indexOf(l.label)
            if (i < 0) 99 else i
        }

        // Si hay etiquetas repetidas, las numeramos.
        val seen = mutableMapOf<String, Int>()
        return sorted.map { l ->
            val n = (seen[l.label] ?: 0) + 1
            seen[l.label] = n
            if (n == 1) l else l.copy(label = l.label + " " + n)
        }
    }

    private fun usable(c: CameraCharacteristics): Boolean {
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList().orEmpty()
        if (!caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) return false
        val sizes = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(ImageFormat.JPEG)
        return sizes != null && sizes.isNotEmpty()
    }

    private fun name(c: CameraCharacteristics): String {
        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (minFocus >= 15f) return "Macro"
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        if (f > 0f && s != null) {
            val eq = f * 43.27f / hypot(s.width, s.height)
            return when {
                eq < 19f -> "Ultra gran angular"
                eq <= 45f -> "Principal"
                else -> "Teleobjetivo"
            }
        }
        return "Principal"
    }
}
