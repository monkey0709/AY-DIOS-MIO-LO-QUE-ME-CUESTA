# Cámara Nocturna

App Android (Camera2) con modos Foto, Noche, Larga exposición (hasta 60 s) y Video.
Guarda en Pictures/CamaraNocturna y Movies/CamaraNocturna.

## Cómo obtener el APK
1. Creá un repositorio en GitHub y subí TODO el contenido de esta carpeta (incluida `.github`).
2. En GitHub: pestaña **Actions** → "Build APK" → esperá ~5 min a que termine (tilde verde).
3. Entrá a esa ejecución y bajá **CamaraNocturna-APK** (al final de la página, sección Artifacts).
4. Descomprimí el .zip, pasá `app-debug.apk` al celular e instalalo (permití "instalar apps desconocidas").

Si el build falla (X roja), abrí el paso "Compilar APK", copiá el error y pasáselo a Claude.
